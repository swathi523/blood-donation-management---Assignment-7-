function sidebar()
{
    const s=document.querySelector('.sidebar');
    s.style.display='flex';
}
function closeSidebar()
{
    const s=document.querySelector('.sidebar');
    s.style.display='none';
}
